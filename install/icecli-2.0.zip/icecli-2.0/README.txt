# Licensed Materials - Property of IBM
# (C) Copyright IBM Corp. 2011, 2013. All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

ICE CLI 2.0 - IBM Containers Command Line Interface

Installation Steps:
-------------------
Pre-reqs: python, python setup-tools, python pip,
recommended: python virtualenv

[If this is not the first time to install the tool on this machine, uninstall previous ver first.
Please see below section on un-installation.]

1- Obtain the distribution package (icecli-2.0.zip or icecli-2.0.tar.gz)

2- Install
pip install icecli-2.0.zip
or
pip install icecli-2.0.tar.gz

Alternatively, you can unzip the zip file, then:
cd icecli-2.0
pip install

Now you are ready to use ice to manage containers, images, and floating ips in the cloud.

Example help commands:
ice -h
ice login -h
ice run -h
ice ps -h
ice images -h
ice ip -h

Troubleshooting:
----------------
- If python setuptools is not already installed on your machine, please refer to https://pypi.python.org/pypi/setuptools.

- Make sure docker cli and cf cli are on your path, or alternatively, edit ice-cfg.ini to set the path to your executables.

ice-cfg.ini is located in a dir called .ice in your home dir. It is created the first time you run ice and login
successfully. You may alternatively manually create the dir and file.
Example ice-cfg.ini file with docker path set:

[DEFAULT}
docker_path = /usr/bin/docker
cf_path = /usr/bin/cf

- On some platforms, you may run into permission problems while installing the cli, prefix the installation command by "sudo"
in this case.

- On some platforms (e.g., Windows), you may need to set the environment variable PYTHONPATH to point at the installed icecli
python scripts. You can do this from administrative console. The path to the installed python scripts is:
<your python home>\Lib\site-packages\icecli\v2

- You may set container cloud service host/url, registry host, and cf api host/url in the ice-cfg.ini file instead of typing them as options
to the login command or using the defaults built-in.
Example ice-cfg.ini file with these attributes set:

[DEFAULT}
docker_path = /usr/bin/docker
cf_path = /usr/bin/cf
ccs_host = https://api-ice.ng.bluemix.net/v2/containers
reg_host = registry-ice.ng.bluemix.net
cf_api_url = api.ng.bluemix.net


Uninstalling the CLI tool:
--------------------------
Perform either:

pip uninstall icecli

or

Remove the ice python egg.
Example, on linux:
rm /usr/local/lib/python2.7/dist-packages/icecli*
(you may need to change the above path if you have a different ver of Python, or installed it in a different location)


Reference Material:
-------------------
For Quick start guide and ice commands reference, go to www.bluemix.net/docs/
For user forums go to developer.ibm.com/answers/topics/containers/

